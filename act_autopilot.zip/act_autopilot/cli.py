"""
Command-line interface for Autopilot.
"""

import argparse
import json
import sys
from pathlib import Path
from datetime import datetime, date
import yaml

from .models import AutopilotConfig, Recommendation
from .executor import BudgetExecutor
from .logging_config import setup_logging

# Initialize logger
logger = setup_logging(__name__)


def load_config(config_path: str) -> dict:
    """Load client configuration from YAML."""
    logger.info(f"Loading config from {config_path}")
    
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    logger.info(f"Config loaded: {config.get('client_name', 'Unknown')}")
    return config


def load_recommendations(report_path: str) -> list:
    """Load recommendations from suggestion report JSON."""
    logger.info(f"Loading recommendations from {report_path}")
    
    with open(report_path, 'r') as f:
        data = json.load(f)
    
    recommendations = data.get('recommendations', [])
    logger.info(f"Loaded {len(recommendations)} recommendations")
    
    return recommendations


def create_autopilot_config(config: dict) -> AutopilotConfig:
    """Create AutopilotConfig from YAML config."""
    return AutopilotConfig(
        customer_id=str(config['google_ads']['customer_id']),
        automation_mode=config.get('automation_mode', 'suggest'),
        risk_tolerance=config.get('risk_tolerance', 'conservative'),
        daily_spend_cap=config['spend_caps']['daily'],
        monthly_spend_cap=config['spend_caps']['monthly'],
        brand_is_protected=config.get('protected_entities', {}).get('brand_is_protected', False),
        protected_entities=config.get('protected_entities', {}).get('entities', []),
        max_changes_per_day=config.get('max_changes_per_day', 10)
    )


def cmd_execute(args):
    """Execute recommendations (budget changes only)."""
    
    print("=" * 80)
    print(f"EXECUTION ENGINE - {args.config}")
    print(f"Date: {args.snapshot_date}")
    print(f"Mode: {'LIVE' if args.live else 'DRY-RUN'}")
    print("=" * 80)
    
    # Load config
    config_dict = load_config(args.config)
    config = create_autopilot_config(config_dict)
    client_name = config_dict.get('client_name', 'Unknown')
    
    # Determine report path
    if args.report:
        report_path = args.report
    else:
        # Default: reports/autopilot/{client_name}/{date}.json
        report_dir = Path('reports/autopilot') / client_name
        report_path = report_dir / f"{args.snapshot_date}.json"
    
    if not Path(report_path).exists():
        logger.error(f"Suggestion report not found: {report_path}")
        print(f"\n❌ ERROR: Suggestion report not found: {report_path}")
        print("\nRun suggestion engine first:")
        print(f"  python -m act_autopilot.suggest_engine {args.config} {args.snapshot_date}")
        return 1
    
    # Load recommendations
    recommendations_data = load_recommendations(str(report_path))
    
    # Convert to Recommendation objects
    recommendations = []
    for rec_data in recommendations_data:
        # Handle different field name variations
        campaign_id = (
            rec_data.get('campaign_id') or 
            rec_data.get('entity_id') or 
            rec_data.get('id')
        )
        
        campaign_name = (
            rec_data.get('campaign_name') or
            rec_data.get('entity_name') or
            rec_data.get('name')
        )
        
        rule_id = (
            rec_data.get('rule_id') or
            rec_data.get('rule_name') or
            rec_data.get('rule')
        )
        
        if not campaign_id:
            logger.warning(f"Skipping recommendation without campaign_id: {rec_data}")
            continue
        
        rec = Recommendation(
            rule_id=rule_id or 'UNKNOWN',
            campaign_id=str(campaign_id),
            campaign_name=campaign_name,
            lever=rec_data.get('lever', 'unknown'),
            action=rec_data.get('action', 'unknown'),
            risk_tier=rec_data.get('risk_tier', 'medium'),
            blocked=rec_data.get('blocked', False),
            blocked_reason=rec_data.get('blocked_reason'),
            evidence=rec_data.get('evidence', {}),
            triggering_diagnosis=rec_data.get('triggering_diagnosis'),
            triggering_confidence=rec_data.get('triggering_confidence', 0.0),
            expected_impact=rec_data.get('expected_impact', '')
        )
        recommendations.append(rec)
    
    logger.info(f"Loaded {len(recommendations)} recommendations from report")
    
    if len(recommendations) == 0:
        logger.error("No valid recommendations found in report")
        print("\n❌ ERROR: No valid recommendations found in report")
        return 1
    
    # Filter by rule IDs if specified
    if args.rule_ids:
        rule_ids = [r.strip() for r in args.rule_ids.split(',')]
        recommendations = [r for r in recommendations if r.rule_id in rule_ids]
        logger.info(f"Filtered to {len(recommendations)} recommendations matching rule IDs: {rule_ids}")
        print(f"\nFiltered to {len(recommendations)} recommendations matching: {', '.join(rule_ids)}")
    
    # Confirmation for live mode
    if args.live:
        print("\n⚠️  LIVE MODE - This will make REAL changes to Google Ads!")
        response = input("Type 'yes' to confirm: ")
        if response.lower() != 'yes':
            logger.info("Live mode cancelled by user")
            print("\n❌ Cancelled")
            return 0
    
    # Parse snapshot date
    snapshot_date = date.fromisoformat(args.snapshot_date)
    
    # Create executor
    executor = BudgetExecutor(
        config=config,
        snapshot_date=snapshot_date,
        db_path=args.db_path,
        dry_run=not args.live
    )
    
    # Execute
    logger.info("Starting execution...")
    results = executor.execute(recommendations)
    
    # Display results
    print("\n" + "=" * 80)
    print("EXECUTION RESULTS")
    print("=" * 80)
    
    success_count = sum(1 for r in results if r.success)
    failed_count = len(results) - success_count
    
    print(f"\nTotal executed: {len(results)}")
    print(f"✅ Successful: {success_count}")
    print(f"❌ Failed: {failed_count}")
    
    if results:
        print("\nDetails:")
        print("-" * 80)
        
        for i, result in enumerate(results, 1):
            status = "✅ SUCCESS" if result.success else "❌ FAILED"
            
            print(f"\n{i}. {result.recommendation_id} - {result.campaign_name or result.campaign_id}")
            print(f"   Status: {status}")
            print(f"   Action: {result.action}")
            
            if result.old_value and result.new_value:
                print(f"   Change: £{result.old_value:.2f} → £{result.new_value:.2f} ({result.change_pct:+.1%})")
            
            if result.error_message:
                print(f"   Error: {result.error_message}")
    
    print("\n" + "=" * 80)
    
    if args.live:
        print("\n✅ LIVE execution complete. Changes applied to Google Ads.")
    else:
        print("\n✅ DRY-RUN complete. No changes made (simulation only).")
    
    print(f"\nLogs: logs/executor_{datetime.now().strftime('%Y-%m-%d')}.log")
    
    return 0 if failed_count == 0 else 1


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(description='Autopilot Execution Engine')
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Execute command
    execute_parser = subparsers.add_parser('execute', help='Execute recommendations')
    execute_parser.add_argument('config', help='Path to client config YAML')
    execute_parser.add_argument('snapshot_date', help='Snapshot date (YYYY-MM-DD)')
    execute_parser.add_argument('--live', action='store_true', help='Live mode (default: dry-run)')
    execute_parser.add_argument('--report', help='Path to suggestion report JSON (optional)')
    execute_parser.add_argument('--rule-ids', help='Comma-separated rule IDs to execute (optional)')
    execute_parser.add_argument('--db-path', default='warehouse.duckdb', help='Database path')
    execute_parser.set_defaults(func=cmd_execute)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    return int(args.func(args))


if __name__ == '__main__':
    raise SystemExit(main())
