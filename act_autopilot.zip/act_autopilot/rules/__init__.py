# act_autopilot.rules — Campaign-level optimization rules
