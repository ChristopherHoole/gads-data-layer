from act_autopilot.cli import main

raise SystemExit(main())
