"""
Execution engine for Google Ads campaign changes.
Handles both budget and bid target modifications.

Supports:
- Budget changes (daily budget increases/decreases)
- Bid changes (tROAS/tCPA target adjustments)
- Dry-run mode (simulation)
- Live mode (real API calls)
- Change logging
- Guardrail validation
"""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Dict, Any, Optional
from act_autopilot.models import Recommendation
from act_autopilot.change_log import ChangeLog
from act_autopilot.logging_config import setup_logging

logger = setup_logging(__name__)


@dataclass
class ExecutionResult:
    """Result of executing a single recommendation."""
    success: bool
    message: str
    error: Optional[str] = None
    executed_at: Optional[datetime] = None
    api_response: Optional[Dict] = None


class BudgetExecutor:
    """
    Executes budget and bid changes with validation and logging.
    
    Supports two modes:
    - Dry-run (default): Simulates changes, no API calls
    - Live: Makes real Google Ads API calls
    
    All changes are validated against Constitution guardrails:
    - Cooldown periods (7 days)
    - One-lever rule (budget ↔ bid)
    - Change magnitude limits (±5%/±10%/±15%)
    """
    
    def __init__(
        self,
        customer_id: str,
        db_path: str = "warehouse.duckdb",
        google_ads_client = None
    ):
        """
        Initialize executor.
        
        Args:
            customer_id: Google Ads customer ID (digits only)
            db_path: Path to DuckDB database
            google_ads_client: GoogleAdsClient instance (None for dry-run)
        """
        self.customer_id = customer_id
        self.db_path = db_path
        self.client = google_ads_client
        self.change_log = ChangeLog(db_path)
        
        mode = "DRY-RUN" if google_ads_client is None else "LIVE"
        logger.info(f"BudgetExecutor initialized: customer_id={customer_id}, mode={mode}")
    
    def execute(
        self,
        recommendations: List[Recommendation],
        dry_run: bool = True,
        rule_ids: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Execute a list of recommendations.
        
        Args:
            recommendations: List of Recommendation objects
            dry_run: If True, simulate only. If False, make real API calls.
            rule_ids: Optional list of rule IDs to filter (e.g., ['BUDGET-001', 'BID-001'])
        
        Returns:
            Summary dict with total, successful, failed counts and detailed results
        """
        logger.info(f"Starting execution: total_recommendations={len(recommendations)}, dry_run={dry_run}")
        
        # Filter by rule_ids if provided
        if rule_ids:
            recommendations = [r for r in recommendations if r.rule_id in rule_ids]
            logger.info(f"Filtered by rule_ids: remaining={len(recommendations)}")
        
        # Filter to budget and bid changes only
        executable_types = ['budget_increase', 'budget_decrease', 'bid_tighten', 'bid_loosen', 'bid_hold']
        executable_recs = [r for r in recommendations if r.action_type in executable_types]
        
        logger.info(f"Executable recommendations: {len(executable_recs)} (budget + bid changes)")
        
        results = []
        successful = 0
        failed = 0
        
        for rec in executable_recs:
            result = self._execute_one(rec, dry_run)
            results.append({
                'rule_id': rec.rule_id,
                'campaign_id': rec.entity_id,
                'campaign_name': rec.campaign_name or 'Unknown',
                'action_type': rec.action_type,
                'success': result.success,
                'message': result.message,
                'error': result.error
            })
            
            if result.success:
                successful += 1
            else:
                failed += 1
        
        summary = {
            'total': len(executable_recs),
            'successful': successful,
            'failed': failed,
            'dry_run': dry_run,
            'results': results
        }
        
        logger.info(f"Execution complete: successful={successful}, failed={failed}")
        return summary
    
    def _execute_one(self, rec: Recommendation, dry_run: bool) -> ExecutionResult:
        """Execute a single recommendation."""
        logger.info(f"Executing {rec.rule_id} for campaign {rec.entity_id}")
        
        # Step 1: Pre-flight validation
        validation = self._validate_execution(rec)
        if not validation['valid']:
            logger.warning(f"Validation failed: {validation['reason']}")
            return ExecutionResult(
                success=False,
                message=f"Validation failed: {validation['reason']}",
                error=validation['reason']
            )
        
        # Step 2: Execute based on action type
        if rec.action_type in ['budget_increase', 'budget_decrease']:
            if dry_run:
                result = self._execute_budget_change_dryrun(rec)
            else:
                result = self._execute_budget_change_live(rec)
        
        elif rec.action_type in ['bid_tighten', 'bid_loosen', 'bid_hold']:
            if dry_run:
                result = self._execute_bid_change_dryrun(rec)
            else:
                result = self._execute_bid_change_live(rec)
        
        else:
            logger.error(f"Unknown action type: {rec.action_type}")
            return ExecutionResult(
                success=False,
                message=f"Unknown action type: {rec.action_type}",
                error="Invalid action type"
            )
        
        # Step 3: Log change to database (live mode only, if successful)
        if not dry_run and result.success:
            self._log_change(rec, result)
        
        return result
    
    def _validate_execution(self, rec: Recommendation) -> Dict[str, Any]:
        """
        Pre-flight validation checks.
        
        Checks:
        1. Already blocked by guardrails?
        2. Cooldown period (same lever within 7 days)
        3. One-lever rule (budget ↔ bid within 7 days)
        4. Change magnitude limits
        
        Returns:
            {'valid': True/False, 'reason': str or None}
        """
        # Check 1: Already blocked?
        if rec.blocked:
            return {'valid': False, 'reason': 'Already blocked by guardrails'}
        
        # Determine lever type
        if rec.action_type in ['budget_increase', 'budget_decrease']:
            lever = 'budget'
        elif rec.action_type in ['bid_tighten', 'bid_loosen', 'bid_hold']:
            lever = 'bid'
        else:
            return {'valid': False, 'reason': f'Unknown action type: {rec.action_type}'}
        
        # Check 2: Cooldown (same lever)
        cooldown_violated = self.change_log.check_cooldown(
            customer_id=self.customer_id,
            campaign_id=rec.entity_id,
            lever=lever,
            days=7
        )
        if cooldown_violated:
            return {'valid': False, 'reason': f'Cooldown violation - {lever} changed <7 days ago'}
        
        # Check 3: One-lever rule (opposite lever)
        opposite_lever = 'bid' if lever == 'budget' else 'budget'
        one_lever_violated = self.change_log.check_one_lever(
            customer_id=self.customer_id,
            campaign_id=rec.entity_id,
            lever=lever,
            days=7
        )
        if one_lever_violated:
            return {'valid': False, 'reason': f'One-lever violation - {opposite_lever} changed <7 days ago'}
        
        # Check 4: Change magnitude limits
        abs_change = abs(rec.change_pct)
        
        # Absolute cap: ±20%
        if abs_change > 20.0:
            return {'valid': False, 'reason': f'Change exceeds absolute cap: {rec.change_pct:.1f}% > 20%'}
        
        # Conservative cap: ±5%
        if abs_change > 5.0:
            logger.warning(f"Change exceeds conservative cap: {rec.change_pct:.1f}% > 5%")
        
        return {'valid': True, 'reason': None}
    
    # ========================================================================
    # BUDGET EXECUTION METHODS
    # ========================================================================
    
    def _execute_budget_change_dryrun(self, rec: Recommendation) -> ExecutionResult:
        """Simulate budget change (no API call)."""
        message = f"""DRY-RUN: Would execute {rec.rule_id}
  Campaign: {rec.campaign_name or 'Unknown'} ({rec.entity_id})
  Current: {rec.current_value:.2f}
  Proposed: {rec.recommended_value:.2f}
  Change: {rec.change_pct:+.1f}%
  Validation: PASS
  API call: SIMULATED
  Log: Would save to analytics.change_log"""
        
        logger.info(f"DRY-RUN budget change: {rec.rule_id} campaign={rec.entity_id}")
        return ExecutionResult(success=True, message=message)
    
    def _execute_budget_change_live(self, rec: Recommendation) -> ExecutionResult:
        """Execute real budget change via Google Ads API."""
        if not self.client:
            return ExecutionResult(
                success=False,
                message="No Google Ads client - cannot execute live",
                error="Missing API client"
            )
        
        try:
            # Import here to avoid circular dependency
            from act_autopilot.google_ads_api import update_campaign_budget
            
            # Convert to micros (Google Ads API uses micros)
            new_budget_micros = int(rec.recommended_value * 1_000_000)
            
            # Call API
            logger.info(f"Calling Google Ads API: update_campaign_budget campaign={rec.entity_id}")
            response = update_campaign_budget(
                client=self.client,
                customer_id=self.customer_id,
                campaign_id=rec.entity_id,
                new_budget_micros=new_budget_micros
            )
            
            message = f"""LIVE: Executed {rec.rule_id}
  Campaign: {rec.campaign_name or 'Unknown'} ({rec.entity_id})
  Old budget: ${rec.current_value:.2f}
  New budget: ${rec.recommended_value:.2f}
  Change: {rec.change_pct:+.1f}%
  Status: SUCCESS"""
            
            logger.info(f"Budget change successful: {rec.rule_id}")
            return ExecutionResult(
                success=True,
                message=message,
                executed_at=datetime.utcnow(),
                api_response=response
            )
        
        except Exception as e:
            logger.error(f"Budget change failed: {str(e)}")
            return ExecutionResult(
                success=False,
                message=f"API error: {str(e)}",
                error=str(e)
            )
    
    # ========================================================================
    # BID EXECUTION METHODS
    # ========================================================================
    
    def _execute_bid_change_dryrun(self, rec: Recommendation) -> ExecutionResult:
        """Simulate bid change (no API call)."""
        # Determine bid type from evidence
        bid_type = self._get_bid_type_from_recommendation(rec)
        
        message = f"""DRY-RUN: Would execute {rec.rule_id}
  Campaign: {rec.campaign_name or 'Unknown'} ({rec.entity_id})
  Bid Type: {bid_type}
  Current: {rec.current_value:.2f}
  Proposed: {rec.recommended_value:.2f}
  Change: {rec.change_pct:+.1f}%
  Validation: PASS
  API call: SIMULATED
  Log: Would save to analytics.change_log"""
        
        logger.info(f"DRY-RUN bid change: {rec.rule_id} campaign={rec.entity_id}")
        return ExecutionResult(success=True, message=message)
    
    def _execute_bid_change_live(self, rec: Recommendation) -> ExecutionResult:
        """Execute real bid change via Google Ads API."""
        if not self.client:
            return ExecutionResult(
                success=False,
                message="No Google Ads client - cannot execute live",
                error="Missing API client"
            )
        
        try:
            # Import here to avoid circular dependency
            from act_autopilot.google_ads_api import update_campaign_bidding_strategy
            
            # Determine bid type
            bid_type = self._get_bid_type_from_recommendation(rec)
            
            # Call API
            logger.info(f"Calling Google Ads API: update_campaign_bidding_strategy campaign={rec.entity_id} type={bid_type}")
            response = update_campaign_bidding_strategy(
                client=self.client,
                customer_id=self.customer_id,
                campaign_id=rec.entity_id,
                new_target_value=rec.recommended_value,
                bid_type=bid_type
            )
            
            message = f"""LIVE: Executed {rec.rule_id}
  Campaign: {rec.campaign_name or 'Unknown'} ({rec.entity_id})
  Bid Type: {bid_type}
  Old target: {rec.current_value:.2f}
  New target: {rec.recommended_value:.2f}
  Change: {rec.change_pct:+.1f}%
  Status: SUCCESS"""
            
            logger.info(f"Bid change successful: {rec.rule_id}")
            return ExecutionResult(
                success=True,
                message=message,
                executed_at=datetime.utcnow(),
                api_response=response
            )
        
        except Exception as e:
            logger.error(f"Bid change failed: {str(e)}")
            return ExecutionResult(
                success=False,
                message=f"API error: {str(e)}",
                error=str(e)
            )
    
    def _get_bid_type_from_recommendation(self, rec: Recommendation) -> str:
        """
        Determine bid type (tROAS or tCPA) from recommendation evidence.
        
        Returns:
            'target_roas' or 'target_cpa'
        """
        # Check evidence for bidding strategy indicators
        evidence = rec.evidence or {}
        
        # Look for explicit bid type in evidence
        if 'bid_type' in evidence:
            return evidence['bid_type']
        
        # Infer from evidence keys
        if 'current_target_roas' in evidence or 'target_roas' in evidence:
            return 'target_roas'
        
        if 'current_target_cpa' in evidence or 'target_cpa' in evidence:
            return 'target_cpa'
        
        # Default to tROAS (most common for ecom)
        logger.warning(f"Could not determine bid type for {rec.rule_id}, defaulting to target_roas")
        return 'target_roas'
    
    # ========================================================================
    # LOGGING
    # ========================================================================
    
    def _log_change(self, rec: Recommendation, result: ExecutionResult):
        """Log successful change to database."""
        # Determine lever
        if rec.action_type in ['budget_increase', 'budget_decrease']:
            lever = 'budget'
        else:
            lever = 'bid'
        
        logger.info(f"Logging change to database: {rec.rule_id} lever={lever}")
        
        self.change_log.log_change(
            customer_id=self.customer_id,
            campaign_id=rec.entity_id,
            change_date=datetime.utcnow().date(),
            lever=lever,
            old_value=rec.current_value,
            new_value=rec.recommended_value,
            change_pct=rec.change_pct,
            rule_id=rec.rule_id,
            risk_tier=rec.risk_tier,
            approved_by='system',  # Could be 'user' if manual approval
            executed_at=result.executed_at
        )
        
        logger.info(f"Change logged successfully")
